package kr.ac.kopo.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.ibatis.session.SqlSession;

import kr.ac.kopo.mybatis.MyConfig;
import kr.ac.kopo.vo.ChampionVO;

public class ChampionDAOImpl implements ChampionDAO {
	private SqlSession sqlSession;
	
	public ChampionDAOImpl() {
		sqlSession = new MyConfig().getInstance();
	}
	
	@Override
	public ChampionVO selectChampionByName(String name) throws Exception {
		return sqlSession.selectOne("dao.ChampionDAO.selectChampionByName", name);
	}

}
