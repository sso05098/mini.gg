package kr.ac.kopo.board.service;

import kr.ac.kopo.vo.ChampionVO;

public interface ChampionService {
	ChampionVO findChampionByName(String name) throws Exception;
}
