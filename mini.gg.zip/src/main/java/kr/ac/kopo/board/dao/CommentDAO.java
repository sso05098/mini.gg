package kr.ac.kopo.board.dao;

import java.util.List;

import kr.ac.kopo.vo.CommentVO;

public interface CommentDAO {
    void insertComment(CommentVO comment) throws Exception; // 댓글 추가
    List<CommentVO> selectCommentsByBoardNo(int boardNo) throws Exception; // 게시글에 대한 댓글 조회
}