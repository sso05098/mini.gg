package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;

public class DeleteBoardController implements Controller {
	private BoardService boardService;
	
	public DeleteBoardController() {
		boardService = new BoardService();
	}

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 관리자 여부 확인
		Boolean isAdmin = (Boolean) request.getSession().getAttribute("isAdmin");
		if (isAdmin == null || !isAdmin) {
			response.sendRedirect("index.jsp");
			return null;
		}
		
		int boardId = Integer.parseInt(request.getParameter("boardId"));
		boardService.deleteBoard(boardId);
		
		response.sendRedirect("list.do");
		return null;
	}

}
