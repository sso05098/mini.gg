package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.dao.ChampionDAO;
import kr.ac.kopo.board.dao.ChampionDAOImpl;
import kr.ac.kopo.vo.ChampionVO;

public class ChampionSearchController implements Controller {

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String championName = request.getParameter("championName");
        
        // ChampionDAO 인스턴스 생성
        ChampionDAO championDAO = new ChampionDAOImpl();
        
        // 챔피언 정보 조회
        ChampionVO champion = championDAO.selectChampionByName(championName);
        
        // 검색 결과를 request에 저장
        request.setAttribute("champion", champion);
        
        // 챔피언 결과 JSP로 포워드
        return "/jsp/champion/championResult.jsp"; // 검색 결과 JSP 페이지로 이동
    }

}
