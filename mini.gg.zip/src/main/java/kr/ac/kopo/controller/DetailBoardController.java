package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;
import kr.ac.kopo.board.service.CommentService;
import kr.ac.kopo.vo.BoardVO;
import kr.ac.kopo.vo.CommentVO;

import java.util.List;

public class DetailBoardController implements Controller {

    private BoardService boardService;
    private CommentService commentService;

    public DetailBoardController() {
        boardService = new BoardService();
        commentService = new CommentService();
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String noStr = request.getParameter("no");
        if (noStr == null || noStr.isEmpty()) {
            throw new IllegalArgumentException("게시글 번호가 없습니다.");
        }

        int no;
        try {
            no = Integer.parseInt(noStr); // 게시글 번호 가져오기
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("잘못된 게시글 번호입니다.");
        }

        BoardVO board = boardService.getBoardByNo(no); // 게시글 조회
        if (board == null) {
            throw new Exception("게시글을 찾을 수 없습니다."); // 게시글이 없는 경우 예외 처리
        }

        List<CommentVO> comments = commentService.getCommentsByBoardNo(no); // 댓글 조회

        request.setAttribute("board", board); // 게시글 정보를 request에 저장
        request.setAttribute("comments", comments); // 댓글 정보를 request에 저장

        return "/jsp/board/boardDetail.jsp"; // 상세보기 JSP로 포워드
    }
}
