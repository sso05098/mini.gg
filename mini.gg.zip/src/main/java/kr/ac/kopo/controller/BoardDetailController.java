package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;
import kr.ac.kopo.vo.BoardVO;

public class BoardDetailController implements Controller {
    private BoardService boardService;

    public BoardDetailController() {
        boardService = new BoardService();
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int no = Integer.parseInt(request.getParameter("no")); // 게시글 번호 가져오기
        BoardVO board = boardService.getBoardByNo(no); // 게시글 상세 정보 조회
        
        request.setAttribute("board", board); // 게시글 정보를 request에 저장
        return "/jsp/board/boardDetail.jsp"; // 상세보기 페이지로 이동
    }
}
