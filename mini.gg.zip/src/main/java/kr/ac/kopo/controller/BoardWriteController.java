package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;
import kr.ac.kopo.vo.BoardVO;
import kr.ac.kopo.vo.MemberVO;

public class BoardWriteController implements Controller {
    private BoardService boardService;

    public BoardWriteController() {
        boardService = new BoardService();
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 로그인 상태 확인
        MemberVO user = (MemberVO) request.getSession().getAttribute("user");
        if (user == null) {
            // 로그인하지 않은 경우 alert 창과 함께 로그인 페이지로 리다이렉트
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write("<script>alert('로그인이 필요합니다.'); location.href='/mini.gg/login.do';</script>");
            return null; // 추가적인 처리가 필요 없으므로 null 반환
        }

        
        // 세션에서 사용자 이름 가져오기
        String writer = user.getName();
        /*
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        // 디버깅을 위한 로그
        System.out.println("Title: " + title);
        System.out.println("Content: " + content);

        // Null 체크 및 비어있는지 확인
        if (title == null || title.trim().isEmpty() || 
            content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("제목과 내용은 필수 입력 사항입니다.");
        }
		
		
        BoardVO board = new BoardVO(title,writer content);
        boardService.insertBoard(board);
         */
        //response.sendRedirect("board/list.do");
        return "/jsp/board/writeForm.jsp";
    }
    

}
