package kr.ac.kopo.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;
import kr.ac.kopo.vo.BoardVO;
import kr.ac.kopo.vo.MemberVO;

public class WriteProcessController implements Controller {

    private BoardService boardService;

    public WriteProcessController() {
        boardService = new BoardService();
    }
	
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 로그인 상태 확인
        MemberVO user = (MemberVO) request.getSession().getAttribute("user");
        if (user == null) {
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write("<script>alert('로그인이 필요합니다.'); location.href='/mini.gg/login.do';</script>");
            return null; // 추가적인 처리가 필요 없으므로 null 반환
        }

        // 세션에서 사용자 이름 가져오기
        String writer = user.getName();
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        // Null 체크 및 비어있는지 확인
        if (title == null || title.trim().isEmpty() || 
            content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("제목과 내용은 필수 입력 사항입니다.");
        }
        

        // BoardVO 객체 생성
        BoardVO board = new BoardVO(title, writer, content);
        boardService.insertBoard(board); // 게시글 데이터베이스에 저장

        List<BoardVO> boardList = boardService.searchAllBoard();
		request.setAttribute("boardList", boardList);
        
        // 게시글 작성 후 게시판 목록으로 리다이렉트
        return "/jsp/board/list.jsp"; // 리다이렉트 후 null 반환
    }

}
