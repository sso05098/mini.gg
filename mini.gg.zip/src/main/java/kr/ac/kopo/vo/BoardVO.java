package kr.ac.kopo.vo;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class BoardVO {
    private int no;
    private String title;
    private String writer;
    private String content;
    private Timestamp regDate;
    private int viewCnt; // 조회수
    
	public BoardVO(String title, String writer, String content) {
		super();
		this.title = title;
		this.writer = writer;
		this.content = content;
	}

    // 추가된 생성자
    public BoardVO(BigDecimal no, String title, String writer, String content, Timestamp regDate, BigDecimal viewCnt) {
        this.no = no.intValue(); // BigDecimal을 int로 변환
        this.title = title;
        this.writer = writer;
        this.content = content;
        this.regDate = regDate;
        this.viewCnt = viewCnt.intValue(); // BigDecimal을 int로 변환
    }

	// Getters and Setters
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public int getViewCnt() { // 이 메서드가 있어야 합니다.
        return viewCnt;
    }

    public void setViewCnt(int viewCnt) {
        this.viewCnt = viewCnt;
    }


	@Override
	public String toString() {
		return "BoardVO [no=" + no + ", title=" + title + ", writer=" + writer + ", content=" + content + ", regDate="
				+ regDate + ", viewCnt=" + viewCnt + "]";
	}
    
    
}
