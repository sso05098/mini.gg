package kr.ac.kopo.vo;

import java.sql.Timestamp;

public class CommentVO {
    private int no;              // 댓글 ID
    private int boardNo;        // 게시글 ID
    private String writer;       // 작성자
    private String content;      // 댓글 내용
    private Timestamp regDate;   // 작성일

    // 기본 생성자
    public CommentVO() {}

    // Getters and Setters
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no; // 일반적으로 여기서 NO를 설정하지 않음
    }

    public int getBoardNo() {
        return boardNo;
    }

    public void setBoardNo(int boardNo) {
        this.boardNo = boardNo;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }
}
