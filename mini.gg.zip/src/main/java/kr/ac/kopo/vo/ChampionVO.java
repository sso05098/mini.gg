package kr.ac.kopo.vo;

public class ChampionVO {
    private int id;
    private String name;
    private String description;
    private String runeImageUrl;
    private String itemTreeImageUrl;
    
    public ChampionVO(String name, String description, String imageUrl, String runeImageUrl, String itemTreeImageUrl) {
        this.name = name;
        this.description = description;
        this.runeImageUrl = runeImageUrl;
        this.itemTreeImageUrl = itemTreeImageUrl;
    }
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public String getRuneImageUrl() {
		return runeImageUrl;
	}
	public void setRuneImageUrl(String runeImageUrl) {
		this.runeImageUrl = runeImageUrl;
	}
	public String getItemTreeImageUrl() {
		return itemTreeImageUrl;
	}
	public void setItemTreeImageUrl(String itemTreeImageUrl) {
		this.itemTreeImageUrl = itemTreeImageUrl;
	}
    
    
}
