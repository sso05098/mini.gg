package kr.ac.kopo.framework;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.controller.BoardListController;
import kr.ac.kopo.controller.BoardWriteController;
import kr.ac.kopo.controller.Controller;

public class DispatcherServlet extends HttpServlet {

   private HandlerMapping mappings;
   
   @Override
   public void init(ServletConfig config) throws ServletException {
	   String propName = config.getInitParameter("propName");
//	   System.out.println("propName : " + propName);
       mappings = new HandlerMapping(propName);
   }

   @Override
   protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String contextPath = request.getContextPath();
       String uri = request.getRequestURI();
       uri = uri.substring(contextPath.length());

       try {
           Controller control = mappings.getController(uri);
           if (control == null) {
               throw new ServletException("No handler found for " + uri);
           }
           String callPage = control.handleRequest(request, response);

           // callPage가 "list.do"와 같은 문자열인 경우
           if (callPage != null && callPage.endsWith(".do")) {
               // 새로운 URI로 리다이렉트
               response.sendRedirect(callPage);
           } else if (callPage != null) {
               // JSP 페이지로 포워드
               RequestDispatcher dispatcher = request.getRequestDispatcher(callPage);
               dispatcher.forward(request, response);
           }
       } catch (Exception e) {
           e.printStackTrace();
           throw new ServletException("처리 중 오류 발생: " + e.getMessage());
       }
   }
}