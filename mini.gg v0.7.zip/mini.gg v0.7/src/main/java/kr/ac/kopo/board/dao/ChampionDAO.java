package kr.ac.kopo.board.dao;

import kr.ac.kopo.vo.ChampionVO;

public interface ChampionDAO {
	ChampionVO selectChampionByName(String name) throws Exception;
}
