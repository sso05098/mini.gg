package kr.ac.kopo.controller;

import java.sql.Timestamp;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.board.service.BoardService;
import kr.ac.kopo.board.service.CommentService;
import kr.ac.kopo.vo.BoardVO;
import kr.ac.kopo.vo.CommentVO;
import kr.ac.kopo.vo.MemberVO;

public class AddCommentController implements Controller {

    private CommentService commentService;
    private BoardService boardService;

    public AddCommentController() {
        commentService = new CommentService();
        boardService = new BoardService(); // BoardService 초기화
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        MemberVO user = (MemberVO) request.getSession().getAttribute("user");
        if (user == null) {
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write("<script>alert('로그인이 필요합니다.'); location.href='/mini.gg/login.do';</script>");
            return null;
        }

        String content = request.getParameter("content");
        int boardNo = Integer.parseInt(request.getParameter("boardNo"));

        // 게시글 조회
        BoardVO board = boardService.getBoardByNo(boardNo);
        if (board == null) {
            throw new Exception("게시글을 찾을 수 없습니다.");
        }

        CommentVO comment = new CommentVO();
        comment.setContent(content);
        comment.setWriter(user.getName());
        comment.setBoardNo(boardNo);
        comment.setRegDate(new Timestamp(System.currentTimeMillis())); // 현재 시간으로 설정

        commentService.addComment(comment); // 댓글 추가

        // 댓글 추가 후 게시글 상세 페이지로 리다이렉트
        response.sendRedirect("detail.do?no=" + boardNo); // boardDetail.do로 리다이렉트
        return null; // 리다이렉트 후에는 null을 반환
    }

}
