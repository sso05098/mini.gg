package kr.ac.kopo.board.service;

import java.util.List;

import kr.ac.kopo.board.dao.CommentDAO;
import kr.ac.kopo.board.dao.CommentDAOImpl;
import kr.ac.kopo.vo.CommentVO;

public class CommentService {
    private CommentDAO commentDao;

    public CommentService() {
        commentDao = new CommentDAOImpl();
    }

    public void addComment(CommentVO comment) throws Exception {
        commentDao.insertComment(comment);
    }

    public List<CommentVO> getCommentsByBoardNo(int boardNo) throws Exception {
        return commentDao.selectCommentsByBoardNo(boardNo);
    }
}
