package kr.ac.kopo.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.ac.kopo.mybatis.MyConfig;
import kr.ac.kopo.vo.CommentVO;

public class CommentDAOImpl implements CommentDAO {
    private SqlSession sqlSession;

    public CommentDAOImpl() {
        sqlSession = new MyConfig().getInstance();
    }

    @Override
    public void insertComment(CommentVO comment) throws Exception {
        sqlSession.insert("dao.CommentDAO.insertComment", comment);
        sqlSession.commit();
    }

    @Override
    public List<CommentVO> selectCommentsByBoardNo(int boardNo) throws Exception {
    	sqlSession.clearCache();
        return sqlSession.selectList("dao.CommentDAO.selectCommentsByBoardNo", boardNo);
    }
}
