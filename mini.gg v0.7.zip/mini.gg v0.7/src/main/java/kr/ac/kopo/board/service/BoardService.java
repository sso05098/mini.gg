package kr.ac.kopo.board.service;

import java.sql.Timestamp;
import java.util.List;

import kr.ac.kopo.board.dao.BoardDAO;
import kr.ac.kopo.board.dao.BoardDAOImpl;
import kr.ac.kopo.vo.BoardVO;
import kr.ac.kopo.vo.MemberVO;

public class BoardService {
	
	private BoardDAO boardDao;
	
	public BoardService() {
		boardDao = new BoardDAOImpl();
	}
	
	public MemberVO getMemberById(MemberVO member) throws Exception {
		return boardDao.selectMemberById(member); // 회원 정보 조회 메서드 추가
	}
	
    public void registerMember(MemberVO member) throws Exception {
        boardDao.insertMember(member); // 회원가입
    }
	
	public List<BoardVO> searchAllBoard() throws Exception {
		return boardDao.selectAllBoard(); // 게시판 목록 조회 메서드 추가
	}
    
    public void insertBoard(BoardVO board) throws Exception {
        board.setRegDate(new Timestamp(System.currentTimeMillis())); // 현재 시간으로 설정
        board.setViewCnt(0); // 기본 조회수 설정
        boardDao.insertBoard(board); // DAO 호출
    }
	
    
    public BoardVO getBoardByNo(int no) throws Exception {
        return boardDao.selectBoardByNo(no); // DAO에서 게시글 조회
    }
    
    /*
	public List<BoardVO> searchAllBoard() throws Exception {
	List<BoardVO> boardList = boardDao.selectAllBoard();
		return boardList;
	}
	*/
}
